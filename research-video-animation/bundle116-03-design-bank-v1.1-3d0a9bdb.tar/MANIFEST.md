# JJK explainer - design bank v1.1 (2026-11-21)

13 files + SHA256SUMS. Corrects bundle115 (bank v1) after QA review; v1 remains preserved
unchanged (corrections append, never overwrite). PRIVATE preservation; no publishing.
External durable backup UNCONFIRMED. Preparation, NOT accepted finish; not delivered to P.

v1.1 corrections (all four QA findings fixed at source):
1. Facing conflict: side-view head profile AND boot toes now both point LEFT (consistent
   facing for the punch-approach scene).
2. Stiff silhouette: torso widened (~222-390 vs ~228-372), legs slightly shortened with
   wider feet; front/rear limbs use lighter/darker tones for readable separation.
3. Hierarchy/metadata mismatch: gojo-side.svg now NESTS head + both arms inside the torso
   group exactly as pivots.json declares - rotating the torso carries head/arms.
   pivots.json updated to the v1.1 geometry.
4. Fist: redrawn with a clear four-bump knuckle row, visible wrapped thumb and separation
   grooves for the decisive closeup.

Carried from v1 unchanged: gojo-front, sukuna-front, ui-components, backgrounds,
hex-shield, palette.json, STYLE-SPEC.md (10 observed principles from the QA-verified
Silenthys Short reference MIGjmXaVWsU + Toji short KXS2J-iY0EQ).

ADOPTION NOTE (Main 14:52): producer has independently built its own articulated parametric
rig with a walking proof under QA. This bank is preserved as compatible original assets and
style ground-truth (palette, UI components, design principles); DO NOT force bank adoption
over the working producer rig. Reconcile bank vs producer rig after proof review.

Boundaries unchanged: original flat-style artwork; JJK likenesses private-use derivatives;
creator captures stay QA/Main-held; reference gait method UNVERIFIED; rebuilt scenes need
visual comparison before acceptance.
