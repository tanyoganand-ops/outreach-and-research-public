# JJK explainer design bank - style spec v1 (2026-11-21)

Grounded in the QA-verified reference: Silenthys, "The math behind Gojo's Infinity"
(https://www.youtube.com/shorts/MIGjmXaVWsU, channel https://www.youtube.com/@Silenthys/shorts),
plus the Toji short (https://youtube.com/shorts/KXS2J-iY0EQ). Evidence: two QA frame strips
(ref_gojo_strip-924822fb.png, ref_toji_strip-ac892e9f.png) and one live playback frame
(cloud-browser-20261121-144910). Observed still-design principles only; reference GAIT/motion
method is UNVERIFIED (no frame-by-frame footage in hand; QA holds playback access).

## Design principles (observed)

1. FLAT VECTOR ILLUSTRATION. Characters are simple flat shapes with 2-tone shading
   (base + one shade), no texture, no gradients on bodies, minimal linework. NOT textured
   anime/manga cutouts. This is the core mismatch P rejected.
2. SCENE GROUNDING. Characters stand on real floors inside illustrated rooms (flat teal
   wall, brown floor, door, picture frame) or on diagram backgrounds (navy grid, starfield,
   radial red). No floating figures on void.
3. DIAGRAM LANGUAGE. All numeric exposition lives in dark navy pills: small-caps muted label
   (#8fa3bd) + big gold value (#e2a862). Examples observed: "DISTANCE LEFT 1/2",
   "1 / 16,384", "SPEED 16 mph", "24 SECONDS", "0.000000561 in".
4. SEGMENTED CUMULATIVE BAR. Halves shown as adjacent gold segments (1/2, 1/4, 1/8, ...)
   shrinking rightward, resolving to "= ONE TRIP" + check mark. (Our v5r3 bars adopted this.)
5. CAPTIONS. White (#f1f4f9) sentence-case text top-of-frame, thin dark outline, ONE bold
   keyword per caption ("never", "cancels", "sukuna beat infinity").
6. ACTOR LABELS. Tiny dark pill with bold white caps ("YOU") tagging the illustrative person.
7. FLAT PROXY CHARACTERS. The illustrative "you" person is ultra-simple flat shapes
   (circle head, rounded-rect body) - detail is reserved for JJK characters.
8. INFOGRAPHIC PROPS. Hex-cell shield wall with infinity glyph + letter-spaced caps label;
   stat cards with thin gold frames ("HEAVENLY RESTRICTION / AGREED BY / NOBODY");
   cursed-energy readouts as gold/white numerals over flat outline figures.
9. ENDCARD. Dark scene + gold rounded pill, small-caps "FOLLOW" over bold "@Silenthys".
10. COLOR GRADING PER SCENE. Each scene commits to one dominant field (navy grid, red,
    starfield, room teal/brown). Palette in palette.json is sampled pixel-exact from the strips.

## What this bank provides (original assets, ours, no creator captures)

- gojo-side.svg: full-body side/profile Gojo, 15 articulated groups with anatomical pivots
  (pivots.json) - the walking/rig base. Legs separate thigh/shin/foot for real gait.
- gojo-front.svg, sukuna-front.svg: front busts, part-separated (head/neck/shoulders).
- fist.svg: flat approaching fist with wrist pivot.
- ui-components.svg: counter pill, segmented trip bar, YOU pill, caption sample, follow pill.
- backgrounds.svg: navy grid, starfield, radial red scene fields.
- hex-shield.svg: hex-cell Infinity wall prop.
- palette.json / pivots.json: machine-readable style + rig data.

## Boundaries

- Style principles are observations; the SVG assets are OUR original flat-style artwork
  (character likenesses are JJK derivatives, private use only - same licence boundary as
  the existing asset bank, no public sharing).
- Reference strips/frames remain QA/Main-held captures, preserved separately, never shipped
  inside distributable artifacts.
- Do not claim style match from this spec alone: any rebuilt scene still needs visual
  comparison against the reference strips before Main accepts it.
